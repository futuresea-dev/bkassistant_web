@extends('layouts.client')
@section('content')
@include("layouts.flash")
<div class="row">
	<div class="col-md-12">
		<div class="questionnaire-wrapper-content pt-3">
			<div class="questionnaire-main-title text-center">
				<h3 class="text-c-blue f-w-800"> Please Upload the Doucments</h3>
				<!--p>Here is the list of documents</p-->
			</div>
		</div>
		<div class="container-1140">
			<div class="upload-documents-wrapper">
				<div class="row">
					<div class="col-md-6 col-12">
						<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
						Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
						</a>
						<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Drivers_License" onclick="file_upload_modal($(this).data('type'))">
							<div class="doc-card">
								<span class="doc-img d-block">
									<img src="{{url('assets/images/documents/licence.png')}}" class="licence-img">
								</span>
								<span class="doc-type d-block">
									<h4 class="text-c-blue f-w-800">Drivers License </h4>
									<span class="file-size text-secondary">70kb</span>
								</span>
							</div>
							<?php if(in_array('Drivers_License',@$documentuploaded)){?>
							<div class="doc-done">
								<img src="{{url('assets/images/documents/doc-done.png')}}">
							</div>
							<?php }?>
						</a>
					</div>
					<div class="col-md-6 col-12">
						<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
						Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
						</a>
						<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Social_Security_Card" onclick="file_upload_modal($(this).data('type'))">
							<div class="doc-card">
								<span class="doc-img d-block">
									<img src="{{url('assets/images/documents/guard.png')}}" alt="">
								</span>
								<span class="doc-type d-block">
									<h4 class="text-c-blue f-w-800">Social Security Card </h4>
									<span class="file-size text-secondary">70kb</span>
								</span>
							</div>
							<?php if(in_array('Social_Security_Card',@$documentuploaded)){?>
							<div class="doc-done">
								<img src="{{url('assets/images/documents/doc-done.png')}}">
							</div>
							<?php }?>
						</a>
					</div>
					<div class="col-md-6 col-12">
						<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
						Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
						</a>
						<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Credit_Report_2_reports" onclick="pdf_upload_modal($(this).data('type'))">
							<div class="doc-card">
								<span class="doc-img d-block">
									<img src="{{url('assets/images/documents/report.png')}}" alt="">
								</span>
								<span class="doc-type d-block">
									<h4 class="text-c-blue f-w-800">Credit Report (2 reports) </h4>
									<span class="file-size text-secondary">70kb</span>
								</span>
							</div>
							<?php if(in_array('Credit_Report_2_reports',@$documentuploaded)){?>
							<div class="doc-done">
								<img src="{{url('assets/images/documents/doc-done.png')}}">
							</div>
							<?php }?>
						</a>
					</div>
					<div class="col-md-6 col-12">
						<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
						Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
						</a>
						<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Last_2_years_Tax_Returns" onclick="pdf_upload_modal($(this).data('type'))">
							<div class="doc-card">
								<span class="doc-img d-block">
									<img src="{{url('assets/images/documents/tax.png')}}" alt="">
								</span>
								<span class="doc-type d-block">
									<h4 class="text-c-blue f-w-800">Last 2 years Tax Returns </h4>
									<span class="file-size text-secondary">70kb</span>
								</span>
							</div>
							<?php if(in_array('Last_2_years_Tax_Returns',@$documentuploaded)){?>
							<div class="doc-done">
								<img src="{{url('assets/images/documents/doc-done.png')}}">
							</div>
							<?php }?>
						</a>
					</div>
					<div class="col-md-6 col-12">
						<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
						Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
						</a>
						<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Last_3_months_Pay_Stubs" onclick="pdf_upload_modal($(this).data('type'))">
							<div class="doc-card">
								<span class="doc-img d-block">
									<img src="{{url('assets/images/documents/credit-card.png')}}" alt="">
								</span>
								<span class="doc-type d-block">
									<h4 class="text-c-blue f-w-800">Last 3 months Pay Stubs </h4>
									<span class="file-size text-secondary">70kb</span>
								</span>
							</div>
							<?php if(in_array('Last_3_months_Pay_Stubs',@$documentuploaded)){?>
							<div class="doc-done">
								<img src="{{url('assets/images/documents/doc-done.png')}}">
							</div>
							<?php }?>
						</a>
					</div>
					<div class="col-md-6 col-12">
						<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
						Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
						</a>
						<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Credit_Counseling_Certificate" onclick="file_upload_modal($(this).data('type'))">
							<div class="doc-card">
								<span class="doc-img d-block">
									<img src="{{url('assets/images/documents/Counseling.png')}}" alt="">
								</span>
								<span class="doc-type d-block">
									<h4 class="text-c-blue f-w-800">Credit Counseling Certificate </h4>
									<span class="file-size text-secondary">70kb</span>
								</span>
							</div>
							<?php if(in_array('Credit_Counseling_Certificate',@$documentuploaded)){?>
							<div class="doc-done">
								<img src="{{url('assets/images/documents/doc-done.png')}}">
							</div>
							<?php }?>
						</a>
					</div>
				</div>
				<hr>
				<div class="optional-document ">
					<h3 class=" f-w-800 pb-3"> Optional Documents</h3>
					<div class="row">
						<div class="col-md-6 col-12">
							<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
							Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
							</a>
							<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Life_Insurance_Declaration_Pages" onclick="file_upload_modal($(this).data('type'))">
								<div class="doc-card">
									<span class="doc-img d-block">
										<img src="{{url('assets/images/documents/life-insurance.png')}}"
											class="licence-img">
									</span>
									<span class="doc-type d-block">
										<h4 class="text-c-blue f-w-800">Life Insurance Declaration Pages </h4>
										<span class="file-size text-secondary">70kb</span>
									</span>
								</div>
								<?php if(in_array('Life_Insurance_Declaration_Pages',@$documentuploaded)){?>
								<div class="doc-done">
									<img src="{{url('assets/images/documents/doc-done.png')}}">
								</div>
								<?php }?>
							</a>
						</div>
						<div class="col-md-6 col-12">
							<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
							Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
							</a>
							<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Current_Mortgage_Statement" onclick="both_upload_modal($(this).data('type'))">
								<div class="doc-card">
									<span class="doc-img d-block">
										<img src="{{url('assets/images/documents/mortgage.png')}}" class="licence-img">
									</span>
									<span class="doc-type d-block">
										<h4 class="text-c-blue f-w-800">Current Mortgage Statement </h4>
										<span class="file-size text-secondary">70kb</span>
									</span>
								</div>
								<?php if(in_array('Current_Mortgage_Statement',@$documentuploaded)){?>
								<div class="doc-done">
									<img src="{{url('assets/images/documents/doc-done.png')}}">
								</div>
								<?php }?>
							</a>
						</div>
						<div class="col-md-6 col-12">
							<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
							Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
							</a>
							<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Current_Auto_Loan_Statement" onclick="both_upload_modal($(this).data('type'))">
								<div class="doc-card">
									<span class="doc-img d-block">
										<img src="{{url('assets/images/documents/cashback.png')}}" class="licence-img">
									</span>
									<span class="doc-type d-block">
										<h4 class="text-c-blue f-w-800">Current Auto Loan Statement </h4>
										<span class="file-size text-secondary">70kb</span>
									</span>
								</div>
								<?php if(in_array('Current_Auto_Loan_Statement',@$documentuploaded)){?>
								<div class="doc-done">
									<img src="{{url('assets/images/documents/doc-done.png')}}">
								</div>
								<?php }?>
							</a>
						</div>
						<div class="col-md-6 col-12">
							<a class="btn shadow-2 mb-4 download-form" data-toggle="modal" data-target="#video_modal" title=" Click for Step by Step video" >
							Click for Step by Step video <img src="{{url('assets/images/video-play.jpg')}}" style="height: 24px;">
							</a>
							<a href="javascript:void(0);" class="doc-card-main" data-toggle="modal" data-type="Miscellaneous_Doucments" onclick="both_upload_modal($(this).data('type'))">
								<div class="doc-card">
									<span class="doc-img d-block">
										<img src="{{url('assets/images/documents/report.png')}}" class="licence-img">
									</span>
									<span class="doc-type d-block">
										<h4 class="text-c-blue f-w-800">Miscellaneous Doucments </h4>
										<span class="file-size text-secondary">70kb</span>
									</span>
								</div>
								<?php if(in_array('Miscellaneous_Doucments',@$documentuploaded)){?>
								<div class="doc-done">
									<img src="{{url('assets/images/documents/doc-done.png')}}">
								</div>
								<?php }?>
							</a>
						</div>

					</div>
				</div>
				<div class="optional-document ">
					<h3 class=" f-w-800 pb-3"> Retainer Documents</h3>
					<div class="row">
						<div class="col-md-6 col-12">
							<a href="{{route('client_retainer_documents')}}" class="btn btn-primary shadow-2 mb-4" style=" width: 400px; ">Next</a>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<div class="modal fade documents-modal" id="image_document_upload_modal" tabindex="-1" role="dialog"
	aria-labelledby="driving-licenceTitle" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content ">
			<form name="form-image" id="form-image" action="{{route('client_document_uploads')}}" method="post" enctype="multipart/form-data" novalidate>
			@csrf
			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
						<div class="upload-area">
							<!-- Header -->
							<div class="upload-area__header">
								<h4 class="text-c-blue upload-area__title f-w-800 font-lg-22">Please Attach a file
								</h4>
								<p class="upload-area__paragraph">
									File should be an image Like .png, .jpg, .jpeg
								</p>
							</div>
							<!-- End Header -->
							<!-- Drop Zoon -->
							<div class="upload-area__drop-zoon drop-zoon">
								<span class="drop-zoon__icon">
									<i class='feather icon-file-text'></i>
								</span>
								<div class="doc-upload">
									<div class="doc-edit">
											<input type="hidden" name="document_type" id="document_type" value="">
											<input type='file'  name="document_file" id="image-licence" accept=".png, .jpg, .jpeg"/>
											<label for="driving-licence">Drop your file here or Click to
												browse</label>
									</div>
								</div>
							</div>
							<div class="doc-preview hide_img_preview position-relative" id="img__preview__DL">
								<img id="image-licence-imagePreview" src="../assets/images/licence.png"
									alt="User profile picture">
								<span class="edit-img"><i class="feather icon-edit"></i></span>
							</div>
							<!-- End Drop Zoon -->
						</div>
					</div>

				</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div>
	</div>
</div>
<div class="modal fade documents-modal" id="pdf_document_upload_modal" tabindex="-1" role="dialog"
	aria-labelledby="driving-licenceTitle" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content ">
			<form name="form-pdf" id="form-pdf" action="{{route('client_document_uploads')}}" method="post" enctype="multipart/form-data" novalidate>
			@csrf
			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
						<div class="upload-area">
							<!-- Header -->
							<div class="upload-area__header">
								<h4 class="text-c-blue upload-area__title f-w-800 font-lg-22">Please Attach a file
								</h4>
								<p class="upload-area__paragraph">
									File should be an Pdf Format
								</p>
							</div>
							<!-- End Header -->
							<!-- Drop Zoon -->
							<div class="upload-area__drop-zoon drop-zoon">
								<span class="drop-zoon__icon">
									<i class='feather icon-file-text'></i>
								</span>
								<div class="doc-upload">
									<div class="doc-edit">										
											<input type="hidden" name="document_type" id="document_type" value="">
											<input type='file'  name="document_file" id="pdf-licence" accept=".pdf"/>
											<label for="driving-licence">Drop your file here or Click to
												browse</label>										
									</div>
								</div>
							</div>
							<div class="doc-preview hide_img_preview position-relative" id="pdf__preview__DL">
								<iframe id="pdf-licence-imagePreview" src="../assets/images/licence.png"
									alt="User profile picture" width="150"height="150" type="application/pdf"></iframe>
								<span class="edit-img"><i class="feather icon-edit"></i></span>
							</div>
							<!-- End Drop Zoon -->
						</div>
					</div>

				</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div>
	</div>
</div>
<div class="modal fade documents-modal" id="both_document_upload_modal" tabindex="-1" role="dialog"
	aria-labelledby="driving-licenceTitle" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content ">
			<form name="form-both" id="form-both" action="{{route('client_document_uploads')}}" method="post" enctype="multipart/form-data" novalidate>
			@csrf
			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
						<div class="upload-area">
							<!-- Header -->
							<div class="upload-area__header">
								<h4 class="text-c-blue upload-area__title f-w-800 font-lg-22">Please Attach a file
								</h4>
								<p class="upload-area__paragraph">
									File should be an image Like .png, .jpg, .jpeg  .pdf
								</p>
							</div>
							<!-- End Header -->
							<!-- Drop Zoon -->
							<div class="upload-area__drop-zoon drop-zoon">
								<span class="drop-zoon__icon">
									<i class='feather icon-file-text'></i>
								</span>
								<div class="doc-upload">
									<div class="doc-edit">										
											<input type="hidden" name="document_type" id="document_type" value="">
											<input type='file'  name="document_file" id="both-licence" accept=".png, .jpg, .jpeg, .pdf"/>
											<label for="driving-licence">Drop your file here or Click to
												browse</label>										
									</div>
								</div>
							</div>
							<div class="doc-preview hide_img_preview position-relative" id="both__preview__DL">
								<img id="both-licence-imagePreview" src="../assets/images/licence.png"
									alt="User profile picture">
								<iframe id="pdfboth-licence-imagePreview" src="../assets/images/licence.png"
									alt="User profile picture" width="150"height="150" type="application/pdf"></iframe>
								<span class="edit-img"><i class="feather icon-edit"></i></span>
							</div>
							<!-- End Drop Zoon -->
						</div>
					</div>

				</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal -->
<div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
		  <div class="modal-body">
		   <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button> 
			<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Jfrjeg26Cwk" id="video"  allowscriptaccess="always" allow="autoplay" style="width: 100%;height: 80%"></iframe>
		 
		  </div>
    </div>
  </div>
</div> 
<style>
#video_modal .modal-dialog {
  height: 90%; /* = 90% of the .modal-backdrop block = %90 of the screen */
  width: 900px;
}
#video_modal .modal-content {
  height: 80%; /* = 100% of the .modal-dialog block */
  width: 900px;
}
.modal {
  text-align: center;
}

@media screen and (min-width: 768px) { 
  #video_modal.modal:before {
    display: inline-block;
    vertical-align: middle;
    content: " ";
    height: 100%;
  }
}

#video_modal .modal-dialog {
	max-width: 100%;
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}
.questionnaire-main-title .text-center{display:none;}
</style>
<link rel="stylesheet" href="{{ asset('assets/css/uploaded-doc.css')}}">
<script src="{{ asset('assets/js/upload-document.js')}}"></script>
@endsection